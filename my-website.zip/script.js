window.onload = function () {
    const button = document.getElementById("clickButton");

    button.addEventListener("click", function () {
        alert("Thanks for clicking!");
    });
};
